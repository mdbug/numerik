package de.fhac.rn.rmichat;

import java.rmi.Naming;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.server.UnicastRemoteObject;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import de.fhac.rn.rmichat.ChatClientCallbackInterface;
import de.fhac.rn.rmichat.ChatServerInterface;

public class ChatServerImpl extends UnicastRemoteObject implements ChatServerInterface {

	private static final long serialVersionUID = 1L;
	private static final int registryPort = 1099;

	// Hier speichern wir die Callbacks!
	private Map<String, ChatClientCallbackInterface> users;

	private ChatServerImpl() throws RemoteException {
		super();
		HashMap<String, ChatClientCallbackInterface> callbackHashMap = new HashMap<>();
		users = Collections.synchronizedMap(callbackHashMap);
	}

	public boolean login(String userID, ChatClientCallbackInterface receiver) throws RemoteException {
		if (this.users.containsKey(userID)) {
			return false;
		} else {
			this.users.put(userID, receiver);
			for (ChatClientCallbackInterface rec : users.values()) {
				rec.receiveUserLogin(userID, users.keySet().toArray());
			}
			return true;
		}
	}

	public void logout(String userID) throws RemoteException {
		if (this.users.containsKey(userID)) {
			users.remove(userID);
			for (ChatClientCallbackInterface rec : users.values()) {
				rec.receiveUserLogout(userID, users.keySet().toArray());
			}
		}
	}

	public void chat(String userID, String message) throws RemoteException {
		for(ChatClientCallbackInterface rec : users.values()){
			rec.receiveChat(userID, message);
		}
	}

	public static void main(String[] args) {
		try {
			 LocateRegistry.createRegistry(registryPort);
			 Naming.bind("rmi://localhost/queue", new ChatServerImpl());
			System.out.println("ChatServer ready");
		} catch (Exception ex) {
			ex.printStackTrace();
			System.exit(0);
		}
	}

	@Override
	public void privateChat(String userID, String message, String receiverID) throws RemoteException {
		if(users.containsKey(receiverID)){
			ChatClientCallbackInterface rec = users.get(receiverID);
			rec.receiveChat(userID, message);
		}else{
			ChatClientCallbackInterface user = users.get(userID);
			user.receiveChat("system", "The user \"" + receiverID + "\" isn't logged in at the moment.");
		}
	}
}
